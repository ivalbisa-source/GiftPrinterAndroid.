package com.giftprinter.android

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import okhttp3.*
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {
    private lateinit var user: EditText
    private lateinit var key: EditText
    private lateinit var printerSpinner: Spinner
    private lateinit var status: TextView
    private var socket: BluetoothSocket? = null
    private var paired = listOf<BluetoothDevice>()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val prefs by lazy { getSharedPreferences("cfg", MODE_PRIVATE) }
    private val spp = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        requestBt()
        buildUi()
        loadPaired()
    }

    private fun requestBt() {
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            val p = arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
            ActivityCompat.requestPermissions(this, p, 77)
        }
    }

    private fun buildUi() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
        }
        val title = TextView(this).apply { text = "🎁 GIFT PRINTER v3"; textSize = 26f }
        user = EditText(this).apply { hint = "TikTok username (tanpa @)"; setText(prefs.getString("user","")) }
        key = EditText(this).apply { hint = "Tik.Tools API Key"; setText(prefs.getString("key","")); inputType=129 }
        printerSpinner = Spinner(this)
        val refresh = Button(this).apply { text="🔄 Muat Printer Bluetooth" }
        val connect = Button(this).apply { text="🔗 Hubungkan Printer" }
        val test = Button(this).apply { text="🧾 TEST PRINT" }
        val listen = Button(this).apply { text="▶ Mulai TikTok LIVE" }
        status = TextView(this).apply { text="Status: belum terhubung"; textSize=16f }
        val note = TextView(this).apply { text="Pair printer dulu di Pengaturan Bluetooth Android. Pilih printer di daftar, lalu Hubungkan."; textSize=14f }
        box.addView(title); box.addView(user); box.addView(key); box.addView(printerSpinner)
        box.addView(refresh); box.addView(connect); box.addView(test); box.addView(listen); box.addView(status); box.addView(note)
        setContentView(box)
        refresh.setOnClickListener { loadPaired() }
        connect.setOnClickListener { connectPrinter() }
        test.setOnClickListener { scope.launch { printReceipt("TEST USER","Test Gift",1,1) } }
        listen.setOnClickListener { startTikTools() }
    }

    private fun loadPaired() {
        if (android.os.Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            status.text="Status: izinkan Nearby devices dulu"; return
        }
        val adapter = BluetoothAdapter.getDefaultAdapter()
        paired = adapter?.bondedDevices?.toList()?.sortedBy { it.name ?: it.address } ?: emptyList()
        printerSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            paired.map { "${it.name ?: "Bluetooth"} — ${it.address}" })
        status.text="Status: ${paired.size} printer/device ter-pair"
    }

    private fun connectPrinter() {
        if (paired.isEmpty()) { status.text="Status: tidak ada perangkat ter-pair"; return }
        val d = paired[printerSpinner.selectedItemPosition]
        scope.launch(Dispatchers.IO) {
            try {
                socket?.close()
                val s = d.createRfcommSocketToServiceRecord(spp)
                s.connect()
                socket=s
                prefs.edit().putString("mac", d.address).apply()
                withContext(Dispatchers.Main){ status.text="Status: printer TERHUBUNG — ${d.name}" }
            } catch(e:Exception) {
                withContext(Dispatchers.Main){ status.text="Status: gagal konek: ${e.message}" }
            }
        }
    }

    private fun startTikTools() {
        val u=user.text.toString().trim().removePrefix("@")
        val k=key.text.toString().trim()
        if(u.isBlank() || k.isBlank()){ status.text="Isi username dan API key dulu"; return }
        prefs.edit().putString("user",u).putString("key",k).apply()
        val req=Request.Builder().url("wss://api.tik.tools?uniqueId=$u&apiKey=$k").build()
        OkHttpClient.Builder().readTimeout(0, TimeUnit.MILLISECONDS).build()
            .newWebSocket(req, object: WebSocketListener(){
                override fun onOpen(ws:WebSocket,response:Response){ runOnUiThread{status.text="Status: TikTok LIVE TERHUBUNG"} }
                override fun onFailure(ws:WebSocket,t:Throwable,r:Response?){ runOnUiThread{status.text="Status LIVE error: ${t.message}"} }
                override fun onMessage(ws:WebSocket,text:String){ handleEvent(text) }
            })
    }

    private fun handleEvent(text:String){
        try{
            val o=JSONObject(text)
            if(o.optString("event")!="gift") return
            val d=o.optJSONObject("data") ?: return
            val u=d.optJSONObject("user") ?: JSONObject()
            val name=u.optString("uniqueId",u.optString("nickname","Viewer"))
            val gift=d.optString("giftName","Gift")
            val count=d.optInt("repeatCount",1)
            val diamonds=d.optInt("diamondCount",0)
            val end=d.optBoolean("repeatEnd",true)
            // Print final combo when repeatEnd=true; otherwise print immediate.
            if(end) scope.launch { printReceipt(name,gift,count,diamonds) }
            runOnUiThread{ status.text="🎁 @$name mengirim $gift ×$count ($diamonds 💎)" }
        }catch(_:Exception){}
    }

    private suspend fun printReceipt(name:String,gift:String,count:Int,diamonds:Int){
        withContext(Dispatchers.Main){ status.text="🖨️ Mencetak @$name — $gift ×$count" }
        val s=socket
        if(s==null || !s.isConnected){
            withContext(Dispatchers.Main){ status.text="⚠️ Printer belum terhubung"; }
            return
        }
        withContext(Dispatchers.IO){
            try{
                val out=s.outputStream
                out.write(byteArrayOf(0x1B,0x40))
                out.write(byteArrayOf(0x1B,0x61,0x01))
                out.write("GIFT PRINTER\n".toByteArray())
                out.write("------------------------------\n".toByteArray())
                out.write("@$name\n".toByteArray())
                out.write("$gift  x$count\n".toByteArray())
                out.write("Diamond: $diamonds\n".toByteArray())
                out.write(SimpleDateFormat("dd/MM/yyyy HH:mm:ss",Locale.getDefault()).format(Date()).toByteArray())
                out.write("\n\n\n".toByteArray())
                out.write(byteArrayOf(0x1B,0x61,0x00))
                out.flush()
                withContext(Dispatchers.Main){ status.text="✅ Berhasil dicetak: @$name" }
            }catch(e:Exception){ withContext(Dispatchers.Main){status.text="❌ Gagal print: ${e.message}"} }
        }
    }

    override fun onDestroy(){ scope.cancel(); try{socket?.close()}catch(_:Exception){}; super.onDestroy() }
}
