# GIFT PRINTER DIGITAL HP — MAX EDITION

Versi profesional untuk HP kedua. Menerima event Gift dari GIFT PRINTER v3 melalui Bluetooth Classic (SPP).

## Fitur
- Struk digital besar dan menarik
- Foto profil supporter sampai 210dp
- Username, Gift, jumlah, waktu
- Total Diamond TIDAK ditampilkan di struk
- Animasi saat Gift masuk
- Riwayat Gift
- Total Gift dan jumlah pengirim
- Top Supporter
- Mode layar tetap menyala
- Menerima protokol JSON dari GIFT PRINTER v3 MAX
- Tetap bisa menerima data tanpa foto; avatar diganti placeholder

## Protokol Bluetooth
GIFT PRINTER v3 MAX mengirim satu JSON per baris:
`{"type":"gift","username":"@user","nickname":"Nama","giftName":"Mawar","count":10,"avatarUrl":"https://...","time":0}`

## Build
Workflow GitHub Actions: `Build Gift Printer Digital HP APK`.
