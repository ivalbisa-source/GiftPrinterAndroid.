package com.giftprinter.digital

import android.Manifest
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import coil.load
import kotlinx.coroutines.*
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.nio.charset.Charset
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    private val sppUuid=UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private val scope=CoroutineScope(SupervisorJob()+Dispatchers.IO)
    private var server:BluetoothServerSocket?=null; private var client:BluetoothSocket?=null
    private lateinit var status:TextView; private lateinit var receiptBox:FrameLayout; private lateinit var history:LinearLayout
    private lateinit var totalView:TextView; private lateinit var senderView:TextView; private lateinit var supporterView:TextView
    private val senders=mutableSetOf<String>(); private var total=0; private var lastGift="Belum ada Gift"
    private val bg=Color.rgb(6,7,13); private val card=Color.rgb(18,19,29); private val pink=Color.rgb(255,45,145); private val purple=Color.rgb(153,67,255); private val cyan=Color.rgb(50,210,255); private val muted=Color.rgb(165,168,184)

    override fun onCreate(b:Bundle?){super.onCreate(b);window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);window.statusBarColor=bg; buildUi(); requestBt()}
    private fun bg(color:Int,r:Float=20f,stroke:Int?=null)=GradientDrawable().apply{setColor(color);cornerRadius=r;stroke?.let{setStroke(2,it)}}
    private fun grad()=GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,intArrayOf(pink,purple)).apply{cornerRadius=28f}
    private fun tv(t:String,s:Float,c:Int=Color.WHITE,b:Boolean=false)=TextView(this).apply{text=t;textSize=s;setTextColor(c);if(b)setTypeface(null,Typeface.BOLD)}
    private fun lp(w:Int=-1,h:Int=-2,l:Int=0,t:Int=0,r:Int=0,b:Int=0)=LinearLayout.LayoutParams(w,h).apply{setMargins(l,t,r,b)}

    private fun buildUi(){
        val scroll=ScrollView(this).apply{setBackgroundColor(bg)}; val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(14,12,14,30)};scroll.addView(root);setContentView(scroll)
        val head=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL}; val brand=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};brand.addView(tv("🎁 GIFT PRINTER",22f,Color.WHITE,true));brand.addView(tv("DIGITAL • MAX EDITION",13f,pink,true));head.addView(brand,lp(0,-2,0,0,8,0));
        val sound=tv("🔊 ON",12f,pink,true).apply{setPadding(14,10,14,10);background=bg(card,24f,0x554f5264)};head.addView(sound);root.addView(head)
        val con=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,13,16,13);background=bg(card,18f,0x6634d9ff)};con.addView(tv("🔵  BLUETOOTH DIGITAL",14f,cyan,true));status=tv("Menunggu koneksi dari GIFT PRINTER v3",12f,muted);con.addView(status);root.addView(con,lp(-1,-2,0,12,0,10))
        val hero=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(0,0,0,0)}
        val title=tv("LIVE GIFT • REAL-TIME",13f,muted,true);title.gravity=Gravity.CENTER;hero.addView(title,lp(-1,-2,0,5,0,8));
        receiptBox=FrameLayout(this).apply{background=bg(Color.TRANSPARENT,22f);minimumHeight=600};hero.addView(receiptBox,lp(-1,-2));root.addView(hero)
        val stats=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL};val a=stat("🎁","TOTAL GIFT",pink);val b=stat("👥","PENGIRIM",purple);stats.addView(a,lp(0,-2,0,0,5,0));stats.addView(b,lp(0,-2,5,0,0,0));totalView=a.findViewWithTag("v") as TextView;senderView=b.findViewWithTag("v") as TextView;root.addView(stats,lp(-1,-2,0,10,0,10))
        val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(14,12,14,12)}
        supporterView=tv("👑  TOP SUPPORTER  •  Belum ada",12f,Color.WHITE,true);top.addView(supporterView,lp(0,-2,0,0,0,0));root.addView(top,lp(-1,-2,0,0,0,10).also{it.setMargins(0,0,0,10)}.apply{})
        val test=Button(this).apply{text="✨  TEST STRUK PREMIUM";isAllCaps=false;textSize=13f;setTextColor(Color.WHITE);background=grad()};root.addView(test,lp(-1,56));test.setOnClickListener{showGift("@DemoViewer","Mawar",10,null,true)}
        val ht=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL};ht.addView(tv("RIWAYAT GIFT",15f,Color.WHITE,true),lp(0,-2,4,18,0,8));val clear=Button(this).apply{text="Hapus";isAllCaps=false;textSize=11f;setTextColor(pink);background=bg(Color.TRANSPARENT,20f,pink)};ht.addView(clear);root.addView(ht);history=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(10,5,10,5);background=bg(card,18f)};root.addView(history);clear.setOnClickListener{history.removeAllViews();total=0;senders.clear();totalView.text="0";senderView.text="0";supporterView.text="👑  TOP SUPPORTER  •  Belum ada"}
        root.addView(tv("GIFT PRINTER DIGITAL • MAX EDITION",10f,muted).apply{gravity=Gravity.CENTER},lp(-1,-2,0,18,0,0))
    }
    private fun stat(icon:String,label:String,accent:Int):LinearLayout{val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(14,12,14,12);background=bg(card,16f)};box.addView(tv(icon,20f));box.addView(tv(label,9f,muted,true));val v=tv("0",25f,accent,true);v.tag="v";box.addView(v);return box}
    private fun requestBt(){if(Build.VERSION.SDK_INT>=31&&ContextCompat.checkSelfPermission(this,Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED)ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.BLUETOOTH_CONNECT,Manifest.permission.BLUETOOTH_SCAN),99)}
    private fun okBt()=Build.VERSION.SDK_INT<31||ContextCompat.checkSelfPermission(this,Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED
    private fun startServer(){if(!okBt()){requestBt();return};val a=BluetoothAdapter.getDefaultAdapter();if(a==null){status.text="Bluetooth tidak tersedia";return};if(!a.isEnabled){status.text="Nyalakan Bluetooth HP";return};scope.launch{try{client?.close();server?.close();server=a.listenUsingRfcommWithServiceRecord("Gift Printer Digital",sppUuid);withContext(Dispatchers.Main){status.text="🟡 Menunggu GIFT PRINTER v3…"};client=server!!.accept();withContext(Dispatchers.Main){status.text="🟢 TERHUBUNG • Siap menerima Gift"};server?.close();server=null;readLoop(client!!)}catch(e:Exception){withContext(Dispatchers.Main){status.text="Koneksi berhenti • Tekan ulang"}}}}
    private suspend fun readLoop(s:BluetoothSocket){val input=s.inputStream;val buf=ByteArray(4096);val acc=StringBuilder();while(isActive&&s.isConnected){val n=try{input.read(buf)}catch(_:Exception){break};if(n<=0)break;acc.append(String(buf,0,n,Charsets.UTF_8));while(true){val i=acc.indexOf("\n");if(i<0)break;val line=acc.substring(0,i).trim();acc.delete(0,i+1);if(line.isNotBlank())withContext(Dispatchers.Main){parseLine(line)}}};withContext(Dispatchers.Main){status.text="🟠 Bluetooth terputus • Tekan TEST/Start lagi"}}
    private fun parseLine(line:String){try{val o=JSONObject(line);if(o.optString("type")=="gift"){showGift(o.optString("username","@viewer"),o.optString("giftName","Gift"),o.optInt("count",1),o.optString("avatarUrl",null),false)}}catch(_:Exception){}}
    private fun showGift(username:String,gift:String,count:Int,avatarUrl:String?,demo:Boolean){val clean=username.removePrefix("@");total+=count;senders.add(clean);totalView.text=total.toString();senderView.text=senders.size.toString();supporterView.text="👑  TOP SUPPORTER  •  @$clean  •  $gift ×$count";lastGift="$gift ×$count";receiptBox.removeAllViews();
        val paper=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_HORIZONTAL;setPadding(18,22,18,28);background=bg(Color.rgb(250,247,242),24f);elevation=18f}
        paper.addView(tv("✦  GIFT DITERIMA  ✦",25f,Color.rgb(36,22,43),true));paper.addView(tv(if(demo)"TEST MODE • PREMIUM RECEIPT" else "TERIMA KASIH ATAS SUPPORTNYA!",11f,Color.rgb(170,44,125),true).apply{gravity=Gravity.CENTER;setPadding(0,4,0,12)})
        val img=ImageView(this).apply{scaleType=ImageView.ScaleType.CENTER_CROP;background=bg(pink,100f);clipToOutline=true;elevation=24f};paper.addView(img,lp(210,210,0,5,0,10));if(!avatarUrl.isNullOrBlank())img.load(avatarUrl){crossfade(true)}else{img.setImageResource(android.R.drawable.ic_menu_myplaces)}
        paper.addView(tv("@$clean",24f,Color.rgb(42,24,47),true));paper.addView(tv("♥  SUPPORTER  ♥",10f,pink,true));paper.addView(tv("MENGIRIM",10f,Color.DKGRAY,true).apply{setPadding(0,14,0,0)});paper.addView(tv("🎁  $gift",29f,Color.rgb(40,24,46),true));paper.addView(tv("× $count",43f,pink,true));paper.addView(tv("Terima kasih, kamu luar biasa! 💖",13f,Color.rgb(80,70,80)).apply{setPadding(0,8,0,12)});paper.addView(tv("✦ GIFT PRINTER DIGITAL ✦",11f,Color.rgb(190,45,125),true));receiptBox.addView(paper,FrameLayout.LayoutParams(-1,-2));
        val pop=AnimatorSet();pop.playTogether(ObjectAnimator.ofFloat(paper,"scaleX",0.88f,1f),ObjectAnimator.ofFloat(paper,"scaleY",0.88f,1f),ObjectAnimator.ofFloat(paper,"alpha",0f,1f));pop.duration=420;pop.start();addHistory(clean,gift,count,avatarUrl)
    }
    private fun addHistory(name:String,gift:String,count:Int,avatar:String?){val row=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL;setPadding(10,10,10,10);background=bg(card,15f)};val im=ImageView(this).apply{scaleType=ImageView.ScaleType.CENTER_CROP;background=bg(pink,50f);clipToOutline=true};if(!avatar.isNullOrBlank())im.load(avatar);row.addView(im,lp(54,54,0,0,10,0));val info=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};info.addView(tv("@$name",14f,Color.WHITE,true));info.addView(tv("$gift  ×$count",12f,muted));row.addView(info,lp(0,-2,0,0,0,0));history.addView(row,0);if(history.childCount>8)history.removeViewAt(history.childCount-1)}
    override fun onResume(){super.onResume();if(::status.isInitialized&&client?.isConnected!=true)startServer()}
    override fun onDestroy(){scope.cancel();try{client?.close();server?.close()}catch(_:Exception){};super.onDestroy()}
}
