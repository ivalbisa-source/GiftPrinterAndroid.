# GIFT PRINTER v3 MAX

Upgrade untuk mengirim Gift ke dua tujuan Bluetooth:
1. Printer thermal fisik.
2. HP kedua yang menjalankan GIFT PRINTER DIGITAL HP MAX.

Event Gift dari Tik.Tools membawa username, nickname, Gift, jumlah, dan URL foto profil. HP v3 mengirim data tersebut sebagai JSON via Bluetooth SPP ke HP digital.

## Urutan penggunaan
1. Pair HP v3 dengan HP digital di pengaturan Bluetooth Android.
2. Di HP digital, buka aplikasi dan biarkan status menunggu/terhubung.
3. Di HP v3, pilih HP digital pada bagian `PRINTER DIGITAL • HP KEDUA`, lalu tekan `HUBUNGKAN HP DIGITAL`.
4. Opsional: pilih printer thermal dan hubungkan juga.
5. Isi username TikTok + API Key Tik.Tools di HP v3.
6. Tekan `MULAI TIKTOK LIVE`.

Catatan: API Key adalah rahasia. Jangan dibagikan.
