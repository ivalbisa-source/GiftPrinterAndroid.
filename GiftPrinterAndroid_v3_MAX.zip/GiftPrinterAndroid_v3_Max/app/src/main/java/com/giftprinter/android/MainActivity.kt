package com.giftprinter.android

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import okhttp3.*
import org.json.JSONObject
import java.util.*
import java.util.concurrent.TimeUnit

class MainActivity:AppCompatActivity(){
 private val spp=UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");private val scope=CoroutineScope(SupervisorJob()+Dispatchers.Main)
 private var thermal:BluetoothSocket?=null;private var digital:BluetoothSocket?=null;private var devices=listOf<BluetoothDevice>();private lateinit var spinner:Spinner;private lateinit var digitalSpinner:Spinner;private lateinit var status:TextView;private lateinit var user:EditText;private lateinit var key:EditText
 private val prefs by lazy{getSharedPreferences("cfg",MODE_PRIVATE)}
 override fun onCreate(b:Bundle?){super.onCreate(b);buildUi();requestBt();loadPaired()}
 private fun buildUi(){val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(22,22,22,28)};val sc=ScrollView(this);sc.addView(root);setContentView(sc)
  root.addView(TextView(this).apply{text="🎁 GIFT PRINTER v3 MAX";textSize=27f})
  user=EditText(this).apply{hint="TikTok username (tanpa @)";setText(prefs.getString("user", ""))};key=EditText(this).apply{hint="Tik.Tools API Key";setText(prefs.getString("key", ""));inputType=129};root.addView(user);root.addView(key)
  root.addView(TextView(this).apply{text="🖨️ PRINTER THERMAL";textSize=18f});spinner=Spinner(this);root.addView(spinner);val ref=Button(this).apply{text="🔄 MUAT PERANGKAT BLUETOOTH"};root.addView(ref);val con=Button(this).apply{text="🔗 HUBUNGKAN PRINTER THERMAL"};root.addView(con)
  root.addView(TextView(this).apply{text="📱 PRINTER DIGITAL • HP KEDUA";textSize=18f});digitalSpinner=Spinner(this);root.addView(digitalSpinner);val dcon=Button(this).apply{text="📡 HUBUNGKAN HP DIGITAL"};root.addView(dcon)
  val test=Button(this).apply{text="🧾 TEST PRINT"};root.addView(test);val live=Button(this).apply{text="▶ MULAI TIKTOK LIVE"};root.addView(live);status=TextView(this).apply{text="Status: siap";textSize=16f};root.addView(status);root.addView(TextView(this).apply{text="HP digital menerima foto profil + username + Gift melalui Bluetooth. Printer thermal tetap bisa dipakai bersamaan.";textSize=13f})
  ref.setOnClickListener{loadPaired()};con.setOnClickListener{connectThermal()};dcon.setOnClickListener{connectDigital()};test.setOnClickListener{scope.launch{sendThermal("TEST USER","Test Gift",1,1)}};live.setOnClickListener{startTikTools()}
 }
 private fun requestBt(){if(android.os.Build.VERSION.SDK_INT>=31)ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.BLUETOOTH_CONNECT,Manifest.permission.BLUETOOTH_SCAN),77)}
 private fun okBt()=android.os.Build.VERSION.SDK_INT<31||ContextCompat.checkSelfPermission(this,Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED
 private fun loadPaired(){if(!okBt()){status.text="Izinkan Nearby devices";return};val a=BluetoothAdapter.getDefaultAdapter();devices=a?.bondedDevices?.toList()?.sortedBy{it.name?:it.address}?:emptyList();val names=devices.map{"${it.name?:"Bluetooth"} — ${it.address}"};spinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,names);digitalSpinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,names);status.text="${devices.size} perangkat ter-pair"}
 private fun connect(device:BluetoothDevice, digitalMode:Boolean){scope.launch(Dispatchers.IO){try{val s=device.createRfcommSocketToServiceRecord(spp);s.connect();if(digitalMode)digital=s else thermal=s;withContext(Dispatchers.Main){status.text=if(digitalMode)"🟢 HP DIGITAL TERHUBUNG — ${device.name}" else "🟢 PRINTER THERMAL TERHUBUNG — ${device.name}"}}catch(e:Exception){withContext(Dispatchers.Main){status.text="❌ Gagal konek: ${e.message}"}}}}
 private fun connectThermal(){if(devices.isEmpty())return;connect(devices[spinner.selectedItemPosition],false)};private fun connectDigital(){if(devices.isEmpty())return;connect(devices[digitalSpinner.selectedItemPosition],true)}
 private fun startTikTools(){val u=user.text.toString().trim().removePrefix("@");val k=key.text.toString().trim();if(u.isBlank()||k.isBlank()){status.text="Isi username dan API Key";return};prefs.edit().putString("user",u).putString("key",k).apply();val req=Request.Builder().url("wss://api.tik.tools?uniqueId=$u&apiKey=$k").build();OkHttpClient.Builder().readTimeout(0,TimeUnit.MILLISECONDS).build().newWebSocket(req,object:WebSocketListener(){override fun onOpen(ws:WebSocket,response:Response){runOnUiThread{status.text="🟢 TIKTOK LIVE TERHUBUNG"}};override fun onFailure(ws:WebSocket,t:Throwable,r:Response?){runOnUiThread{status.text="❌ LIVE error: ${t.message}"}};override fun onMessage(ws:WebSocket,text:String){handleEvent(text)}})}
 private fun handleEvent(text:String){try{val o=JSONObject(text);if(o.optString("event")!="gift")return;val d=o.optJSONObject("data")?:return;val u=d.optJSONObject("user")?:JSONObject();val name=u.optString("uniqueId",u.optString("nickname","viewer"));val nick=u.optString("nickname",name);val gift=d.optString("giftName","Gift");val count=d.optInt("repeatCount",1);val dia=d.optInt("diamondCount",0);val avatar=u.optString("profilePictureUrl","");val end=d.optBoolean("repeatEnd",true);if(end)scope.launch{sendThermal(name,gift,count,dia);sendDigital(name,nick,gift,count,avatar)};runOnUiThread{status.text="🎁 @$name → $gift ×$count"}}catch(_:Exception){}}
 private suspend fun sendDigital(name:String,nick:String,gift:String,count:Int,avatar:String){val s=digital?:return;if(!s.isConnected)return;val o=JSONObject().apply{put("type","gift");put("username", "@$name");put("nickname",nick);put("giftName",gift);put("count",count);put("avatarUrl",avatar);put("time",System.currentTimeMillis())};withContext(Dispatchers.IO){try{s.outputStream.write((o.toString()+"\n").toByteArray(Charsets.UTF_8));s.outputStream.flush()}catch(_:Exception){}}}
 private suspend fun sendThermal(name:String,gift:String,count:Int,dia:Int){val s=thermal?:return;if(!s.isConnected)return;withContext(Dispatchers.IO){try{val out=s.outputStream;out.write(byteArrayOf(0x1B,0x40));out.write(byteArrayOf(0x1B,0x61,0x01));out.write("GIFT PRINTER\n------------------------------\n@$name\n$gift  x$count\n${dia} Diamond\n\n\n".toByteArray());out.flush()}catch(_:Exception){}}}
 override fun onDestroy(){scope.cancel();try{thermal?.close();digital?.close()}catch(_:Exception){};super.onDestroy()}
}
