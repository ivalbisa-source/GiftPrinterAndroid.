package com.giftprinter.android

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import coil.load
import kotlinx.coroutines.*
import okhttp3.*
import org.json.JSONObject
import java.util.*
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {
    private val spp = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var thermal: BluetoothSocket? = null
    private var devices = listOf<BluetoothDevice>()
    private lateinit var spinner: Spinner
    private lateinit var status: TextView
    private lateinit var user: EditText
    private lateinit var key: EditText
    private lateinit var receipt: LinearLayout
    private lateinit var avatar: ImageView
    private lateinit var senderName: TextView
    private lateinit var senderUser: TextView
    private lateinit var giftName: TextView
    private lateinit var giftCount: TextView
    private lateinit var giftIcon: TextView
    private lateinit var empty: TextView
    private lateinit var totalGift: TextView
    private lateinit var senderTotal: TextView
    private var giftTotal = 0
    private var senderSet = mutableSetOf<String>()
    private var lastGiftId = ""

    private val prefs by lazy { getSharedPreferences("cfg", MODE_PRIVATE) }
    private val pink = Color.rgb(244, 55, 145)
    private val purple = Color.rgb(154, 76, 255)
    private val dark = Color.rgb(12, 13, 20)
    private val card = Color.rgb(25, 26, 36)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        buildUi()
        requestBt()
        loadPaired()
    }

    private fun tv(text: String, size: Float, color: Int = Color.WHITE) =
        TextView(this).apply { this.text = text; textSize = size; setTextColor(color) }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 28)
            setBackgroundColor(dark)
        }
        val scroll = ScrollView(this).apply { setBackgroundColor(dark) }
        scroll.addView(root)
        setContentView(scroll)

        val title = tv("🎁 GIFT PRINTER", 28f).apply {
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        root.addView(title)
        root.addView(tv("DIGITAL  •  v3 MAX", 14f, Color.rgb(255, 80, 170)))

        status = tv("● SIAP — tunggu Gift", 14f, Color.rgb(78, 230, 155))
        status.setPadding(16, 14, 16, 14)
        root.addView(status, lp())

        section(root, "⚡ TIKTOK LIVE")
        user = EditText(this).apply {
            hint = "Username TikTok (tanpa @)"
            setText(prefs.getString("user", ""))
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            setSingleLine()
        }
        key = EditText(this).apply {
            hint = "Tik.Tools API Key"
            setText(prefs.getString("key", ""))
            inputType = 129
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            setSingleLine()
        }
        root.addView(user, lp()); root.addView(key, lp())
        val live = button("▶  MULAI TIKTOK LIVE", pink)
        root.addView(live, lp())

        section(root, "🖨️ PRINTER THERMAL (OPSIONAL)")
        spinner = Spinner(this)
        root.addView(spinner, lp())
        val reload = button("🔄 MUAT PERANGKAT BLUETOOTH", purple)
        val connect = button("🔗 HUBUNGKAN PRINTER THERMAL", purple)
        root.addView(reload, lp()); root.addView(connect, lp())

        section(root, "✨ GIFT DIGITAL — LANGSUNG MUNCUL DI HP INI")
        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        totalGift = tv("0\nTOTAL GIFT", 16f, Color.WHITE).apply { gravity = Gravity.CENTER }
        senderTotal = tv("0\nPENGIRIM", 16f, Color.WHITE).apply { gravity = Gravity.CENTER }
        stats.addView(totalGift, weightLp()); stats.addView(senderTotal, weightLp())
        root.addView(stats, lp())

        empty = tv("🎁\n\nBelum ada Gift.\nSaat Gift masuk, foto profil akan muncul besar di sini.", 17f).apply {
            gravity = Gravity.CENTER
            setPadding(20, 55, 20, 55)
        }
        root.addView(empty, lp())

        receipt = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(18, 24, 18, 28)
            setBackgroundColor(Color.rgb(250, 247, 239))
            visibility = View.GONE
        }
        root.addView(receipt, lp())

        avatar = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
        }
        val avatarBox = FrameLayout(this).apply {
            setBackgroundColor(Color.rgb(245, 75, 155))
            addView(avatar, FrameLayout.LayoutParams(220, 220).apply {
                gravity = Gravity.CENTER
                setMargins(6, 6, 6, 6)
            })
        }
        receipt.addView(avatarBox, LinearLayout.LayoutParams(232, 232).apply { gravity = Gravity.CENTER })

        senderUser = TextView(this).apply {
            textSize = 18f; setTextColor(Color.rgb(210, 35, 120)); gravity = Gravity.CENTER
        }
        senderName = TextView(this).apply {
            textSize = 29f; setTextColor(Color.rgb(20, 20, 30)); gravity = Gravity.CENTER
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        giftIcon = TextView(this).apply {
            text = "🎁"; textSize = 54f; gravity = Gravity.CENTER
        }
        giftName = TextView(this).apply {
            textSize = 25f; setTextColor(Color.rgb(25, 25, 35)); gravity = Gravity.CENTER
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        giftCount = TextView(this).apply {
            textSize = 40f; setTextColor(Color.rgb(235, 40, 130)); gravity = Gravity.CENTER
            setTypeface(null, android.graphics.Typeface.BOLD)
        }

        receipt.addView(tv("✦  GIFT DITERIMA  ✦", 25f, Color.rgb(210, 35, 120)).apply {
            gravity = Gravity.CENTER; setTypeface(null, android.graphics.Typeface.BOLD)
        }, lp())
        receipt.addView(tv("Terima kasih atas supportnya! ❤️", 14f, Color.DKGRAY).apply { gravity = Gravity.CENTER }, lp())
        receipt.addView(senderUser, lp())
        receipt.addView(senderName, lp())
        receipt.addView(tv("────────  MENGIRIM  ────────", 13f, Color.GRAY).apply { gravity = Gravity.CENTER }, lp())
        receipt.addView(giftIcon, lp())
        receipt.addView(giftName, lp())
        receipt.addView(giftCount, lp())
        receipt.addView(tv("Terima kasih sudah support! 💖", 16f, Color.DKGRAY).apply {
            gravity = Gravity.CENTER
        }, lp())

        val test = button("🎁  TEST STRUK", pink)
        root.addView(test, lp())
        reload.setOnClickListener { loadPaired() }
        connect.setOnClickListener { connectThermal() }
        test.setOnClickListener {
            showGift("DemoViewer", "Demo Viewer", "Mawar", 10, "")
        }
        live.setOnClickListener { startTikTools() }
    }

    private fun section(root: LinearLayout, text: String) {
        root.addView(tv(text, 18f, Color.WHITE).apply {
            setPadding(0, 22, 0, 8)
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
    }

    private fun lp() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { setMargins(0, 7, 0, 7) }

    private fun weightLp() = LinearLayout.LayoutParams(
        0, 82, 1f
    ).apply { setMargins(5, 5, 5, 5) }

    private fun button(text: String, color: Int) = Button(this).apply {
        this.text = text
        setTextColor(Color.WHITE)
        setBackgroundColor(color)
        textSize = 14f
    }

    private fun requestBt() {
        if (android.os.Build.VERSION.SDK_INT >= 31)
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN), 77
            )
    }

    private fun okBt() =
        android.os.Build.VERSION.SDK_INT < 31 ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) ==
                PackageManager.PERMISSION_GRANTED

    private fun loadPaired() {
        if (!okBt()) { status.text = "⚠ Izinkan Nearby devices"; return }
        val a = BluetoothAdapter.getDefaultAdapter()
        devices = a?.bondedDevices?.toList()?.sortedBy { it.name ?: it.address } ?: emptyList()
        val names = devices.map { "${it.name ?: "Bluetooth"} — ${it.address}" }
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        status.text = "● ${devices.size} perangkat Bluetooth ter-pair"
    }

    private fun connectThermal() {
        if (devices.isEmpty()) { status.text = "⚠ Pair printer dulu di Pengaturan Bluetooth"; return }
        val device = devices[spinner.selectedItemPosition]
        scope.launch(Dispatchers.IO) {
            try {
                val s = device.createRfcommSocketToServiceRecord(spp)
                s.connect()
                thermal = s
                withContext(Dispatchers.Main) {
                    status.text = "🟢 PRINTER TERHUBUNG — ${device.name}"
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { status.text = "❌ Printer gagal terhubung" }
            }
        }
    }

    private fun startTikTools() {
        val u = user.text.toString().trim().removePrefix("@")
        val k = key.text.toString().trim()
        if (u.isBlank() || k.isBlank()) {
            status.text = "⚠ Isi username dan API Key Tik.Tools"
            return
        }
        prefs.edit().putString("user", u).putString("key", k).apply()
        val req = Request.Builder()
            .url("wss://api.tik.tools?uniqueId=$u&apiKey=$k").build()
        OkHttpClient.Builder().readTimeout(0, TimeUnit.MILLISECONDS).build()
            .newWebSocket(req, object : WebSocketListener() {
                override fun onOpen(ws: WebSocket, response: Response) {
                    runOnUiThread { status.text = "🟢 TIKTOK LIVE TERHUBUNG • menunggu Gift..." }
                }
                override fun onFailure(ws: WebSocket, t: Throwable, r: Response?) {
                    runOnUiThread { status.text = "❌ LIVE error: ${t.message ?: "koneksi gagal"}" }
                }
                override fun onMessage(ws: WebSocket, text: String) { handleEvent(text) }
            })
    }

    private fun handleEvent(text: String) {
        try {
            val o = JSONObject(text)
            if (o.optString("event") != "gift") return
            val d = o.optJSONObject("data") ?: return
            val u = d.optJSONObject("user") ?: JSONObject()
            val name = u.optString("uniqueId", u.optString("nickname", "viewer"))
            val nick = u.optString("nickname", name)
            val gift = d.optString("giftName", "Gift")
            val count = d.optInt("repeatCount", 1).coerceAtLeast(1)
            val dia = d.optInt("diamondCount", 0)
            val avatarUrl = u.optString("profilePictureUrl", "")
            val transactionId = d.optString("transactionId", "")
            val end = d.optBoolean("repeatEnd", true)
            val id = if (transactionId.isNotBlank()) transactionId else "$name|$gift|$count|$avatarUrl"
            if (!end || id == lastGiftId) return
            lastGiftId = id
            runOnUiThread { showGift(name, nick, gift, count, avatarUrl) }
            scope.launch { sendThermal(name, gift, count, dia) }
        } catch (_: Exception) {}
    }

    private fun showGift(name: String, nick: String, gift: String, count: Int, avatarUrl: String) {
        empty.visibility = View.GONE
        receipt.visibility = View.VISIBLE
        senderUser.text = "@$name"
        senderName.text = nick
        giftName.text = gift
        giftCount.text = "× $count"
        giftIcon.text = giftEmoji(gift)
        if (avatarUrl.isNotBlank()) {
            avatar.load(avatarUrl) {
                crossfade(true)
                placeholder(android.R.drawable.ic_menu_gallery)
                error(android.R.drawable.ic_menu_gallery)
            }
        } else {
            avatar.setImageResource(android.R.drawable.ic_menu_gallery)
        }
        giftTotal += count
        senderSet.add(name)
        totalGift.text = "$giftTotal\nTOTAL GIFT"
        senderTotal.text = "${senderSet.size}\nPENGIRIM"
        receipt.animate().scaleX(1.04f).scaleY(1.04f).setDuration(140)
            .withEndAction { receipt.animate().scaleX(1f).scaleY(1f).setDuration(180).start() }.start()
    }

    private fun giftEmoji(gift: String): String {
        val s = gift.lowercase(Locale.getDefault())
        return when {
            "rose" in s || "mawar" in s -> "🌹"
            "heart" in s || "love" in s || "hati" in s -> "❤️"
            "coffee" in s || "kopi" in s -> "☕"
            "lion" in s || "singa" in s -> "🦁"
            "galaxy" in s -> "🌌"
            else -> "🎁"
        }
    }

    private suspend fun sendThermal(name: String, gift: String, count: Int, dia: Int) {
        val s = thermal ?: return
        if (!s.isConnected) return
        withContext(Dispatchers.IO) {
            try {
                val out = s.outputStream
                out.write(byteArrayOf(0x1B, 0x40))
                out.write(byteArrayOf(0x1B, 0x61, 0x01))
                out.write("GIFT PRINTER\n------------------------------\n@$name\n$gift  x$count\n\nTerima kasih!\n\n\n".toByteArray())
                out.flush()
            } catch (_: Exception) {}
        }
    }

    override fun onDestroy() {
        scope.cancel()
        try { thermal?.close() } catch (_: Exception) {}
        super.onDestroy()
    }
}
