# GIFT PRINTER v4 DIGITAL MAX

Satu aplikasi saja: Tik.Tools -> Gift -> foto profil besar langsung tampil di layar HP.
Printer thermal Bluetooth tetap opsional.

- Username + Tik.Tools API Key
- TikTok LIVE WebSocket
- Foto profil Gift langsung tampil besar
- Nama, username, Gift, jumlah
- Total Gift & jumlah pengirim
- Test struk
- Bluetooth printer thermal opsional
