GIFT PRINTER ANDROID v3

Fitur:
- Tik.Tools WebSocket untuk event gift TikTok LIVE.
- Menampilkan status gift masuk.
- Bluetooth Classic SPP untuk printer thermal ESC/POS.
- Daftar perangkat Bluetooth yang sudah dipair.
- Connect printer dan TEST PRINT.
- Cetak username, gift, jumlah, diamond, waktu.
- Permission Android 12+ untuk Bluetooth.

CARA BUILD APK:
1. Install Android Studio.
2. File > New > Import Project, pilih folder GiftPrinterAndroid_v3.
3. Tunggu Gradle Sync selesai.
4. Build > Build APK(s).
5. APK debug biasanya ada di app/build/outputs/apk/debug/app-debug.apk.

CARA PAKAI:
1. Pair printer thermal dari Settings > Bluetooth.
2. Buka aplikasi.
3. Izinkan Nearby devices.
4. Pilih printer > Hubungkan Printer.
5. Tekan TEST PRINT.
6. Isi username TikTok dan API key Tik.Tools.
7. Tekan Mulai TikTok LIVE.

CATATAN:
- Tik.Tools adalah layanan pihak ketiga, bukan API resmi TikTok.
- Printer harus mendukung Bluetooth Classic SPP dan perintah ESC/POS.
- Implementasi v3 mencetak teks; foto profil belum dicetak agar kompatibilitas printer lebih luas.
